export default interface IdAccessRefreshTokenResponse {
  idToken: string;
  accessToken: string;
  refreshToken: string;
  firstName: string;
  lastName: string;
  userName: string;
}

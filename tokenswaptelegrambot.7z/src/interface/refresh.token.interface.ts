export default interface RefreshTokenInterface {
  sub: string;
  aud: string;
  iss: string;
  session: string;
}

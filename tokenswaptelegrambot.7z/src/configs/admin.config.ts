export const adminConfig = {
    "devang": {
        telegramId: '1001388295'
    },
}